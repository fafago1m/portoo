# Ikon orang loading

File `src/components/ui/waving-developer.tsx` adalah ilustrasi orang untuk halaman loading. Bentuk badan, tangan, dan animasinya dibuat langsung dengan SVG di dalam komponen, jadi bisa diedit tanpa file gambar tambahan.

Komponen ini dipakai oleh `PageLoader` melalui:

```tsx
import { WavingDeveloper } from "./waving-developer";
```

Perubahan pada file komponen ini akan langsung mengubah ikon loading.
